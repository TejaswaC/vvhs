package com.cts.VehicleReservationSystem.dao;

public interface ScheduleMailDAO {
	public String sendMail();

}
